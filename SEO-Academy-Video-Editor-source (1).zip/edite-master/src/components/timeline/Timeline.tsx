import {
  type MouseEvent as ReactMouseEvent,
  type PointerEvent as ReactPointerEvent,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  ArrowDownToLine,
  ArrowUpToLine,
  AudioLines,
  Camera,
  ChevronsLeft,
  Clipboard,
  Copy,
  CopyPlus,
  Diamond,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  LockOpen,
  Magnet,
  Merge,
  MousePointerClick,
  Pencil,
  Plus,
  Scissors,
  Snowflake,
  Trash2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useEditorStore } from '@/store/editorStore';
import { canMergeClips, clipSnapTargets, clipTimelineDuration, projectDuration, snapStart } from '@/lib/timeline';
import { MIN_CLIP, ZOOM_MAX, ZOOM_MIN } from '@/lib/constants';
import { clamp, cn, formatClock } from '@/lib/utils';
import { ContextMenu, type ContextMenuState, type MenuItem } from '@/components/ui/ContextMenu';
import { PlaybackControls } from '@/components/preview/PlaybackControls';
import { useSnapshot } from '@/hooks/useSnapshot';
import { TimelineClip } from './TimelineClip';
import { Playhead } from './Playhead';
import { ZoomControls } from './ZoomControls';

const ROW_H = 56;

function niceStep(pxPerSec: number): number {
  if (pxPerSec <= 0) return 0;
  const target = 80 / pxPerSec;
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
  return steps.find((s) => s >= target) ?? 600;
}

export function Timeline() {
  const media = useEditorStore((s) => s.media);
  const tracks = useEditorStore((s) => s.tracks);
  const clips = useEditorStore((s) => s.clips);
  const activeId = useEditorStore((s) => s.activeClipId);
  const selectedIds = useEditorStore((s) => s.selectedIds);
  const clipboard = useEditorStore((s) => s.clipboard);
  const zoom = useEditorStore((s) => s.zoom);
  const snap = useEditorStore((s) => s.snap);
  const toggleSnap = useEditorStore((s) => s.toggleSnap);
  const currentTime = useEditorStore((s) => s.playback.currentTime);
  const setCurrentTime = useEditorStore((s) => s.setCurrentTime);
  const setPlaying = useEditorStore((s) => s.setPlaying);
  const setZoom = useEditorStore((s) => s.setZoom);
  const setActiveClip = useEditorStore((s) => s.setActiveClip);
  const toggleSelect = useEditorStore((s) => s.toggleSelect);
  const selectClips = useEditorStore((s) => s.selectClips);
  const clearSelection = useEditorStore((s) => s.clearSelection);
  const moveClip = useEditorStore((s) => s.moveClip);
  const moveClipToNewTrack = useEditorStore((s) => s.moveClipToNewTrack);
  const setClipStarts = useEditorStore((s) => s.setClipStarts);
  const updateClip = useEditorStore((s) => s.updateClip);
  const updateClips = useEditorStore((s) => s.updateClips);
  const splitAt = useEditorStore((s) => s.splitAt);
  const mergeClips = useEditorStore((s) => s.mergeClips);
  const addKeyframeAtPlayhead = useEditorStore((s) => s.addKeyframeAtPlayhead);
  const freezeFrame = useEditorStore((s) => s.freezeFrame);
  const extractAudio = useEditorStore((s) => s.extractAudio);
  const duplicateClips = useEditorStore((s) => s.duplicateClips);
  const copyClips = useEditorStore((s) => s.copyClips);
  const pasteClips = useEditorStore((s) => s.pasteClips);
  const deleteClips = useEditorStore((s) => s.deleteClips);
  const rippleDeleteClips = useEditorStore((s) => s.rippleDeleteClips);
  const addTrack = useEditorStore((s) => s.addTrack);
  const removeTrack = useEditorStore((s) => s.removeTrack);
  const pruneEmptyTracks = useEditorStore((s) => s.pruneEmptyTracks);
  const setTrackMuted = useEditorStore((s) => s.setTrackMuted);
  const setTrackHidden = useEditorStore((s) => s.setTrackHidden);
  const setTrackLocked = useEditorStore((s) => s.setTrackLocked);
  const renameTrack = useEditorStore((s) => s.renameTrack);
  const moveTrack = useEditorStore((s) => s.moveTrack);
  const { snapshot, busy: snapping } = useSnapshot();

  const displayDuration = Math.max(projectDuration(clips), 8);
  const hasSelection = selectedIds.length > 0;
  const selectedClips = clips.filter((c) => selectedIds.includes(c.id));
  const allHidden = hasSelection && selectedClips.every((c) => c.hidden);
  // Selected clips that carry sound (a video with audio, or detached/standalone audio).
  const mutableClips = selectedClips.filter((c) => {
    const m = media.find((x) => x.id === c.mediaId);
    return m?.kind === 'audio' || (m?.kind === 'video' && m.hasAudio);
  });
  const allMuted = mutableClips.length > 0 && mutableClips.every((c) => c.muted);
  const activeClip = clips.find((c) => c.id === activeId);
  const canKeyframe = !!activeClip && !activeClip.text;
  const kfAtPlayhead =
    !!activeClip &&
    (activeClip.keyframes ?? []).some((k) => Math.abs(activeClip.start + k.at - currentTime) < 0.02);

  const scrollRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const rowsRef = useRef<HTMLDivElement>(null);
  const [viewW, setViewW] = useState(0);
  const [menu, setMenu] = useState<ContextMenuState | null>(null);
  const [dragClipId, setDragClipId] = useState<string | null>(null);
  const [overNewTrack, setOverNewTrack] = useState(false);
  // The existing track a dragged clip would drop onto (for the row highlight).
  const [dropTrackId, setDropTrackId] = useState<string | null>(null);
  const [renamingTrackId, setRenamingTrackId] = useState<string | null>(null);
  // Set on Escape so the input's blur (fired as it unmounts) cancels instead of commits.
  const renameCancel = useRef(false);
  const pendingFocus = useRef<{ time: number; offset: number } | null>(null);
  // Latest px/sec for the touch listeners (bound once), and a flag set while a
  // two-finger pinch is in progress so the scrub doesn't fight it.
  const pxPerSecRef = useRef(0);
  const pinchRef = useRef(false);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const update = () => setViewW(el.clientWidth);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const pxPerSec = displayDuration > 0 && viewW > 0 ? Math.max(6, (viewW / displayDuration) * zoom) : 0;
  const trackW = displayDuration * pxPerSec;
  pxPerSecRef.current = pxPerSec;

  useEffect(() => {
    const el = scrollRef.current;
    if (el && pendingFocus.current && pxPerSec > 0) {
      el.scrollLeft = pendingFocus.current.time * pxPerSec - pendingFocus.current.offset;
      pendingFocus.current = null;
    }
  }, [pxPerSec]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (pxPerSec <= 0) return;
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const rect = el.getBoundingClientRect();
        const contentX = e.clientX - rect.left + el.scrollLeft;
        pendingFocus.current = { time: contentX / pxPerSec, offset: e.clientX - rect.left };
        setZoom(clamp(zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12), ZOOM_MIN, ZOOM_MAX));
      } else if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
        e.preventDefault();
        el.scrollLeft += e.deltaX;
      }
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [pxPerSec, zoom, setZoom]);

  // Pinch (two fingers) zooms the track view, centred on the pinch midpoint via
  // the same pendingFocus mechanism as ctrl+wheel. Bound once with refs so a
  // mid-gesture zoom (which re-renders) never resets the in-flight pinch.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const dist = (t: TouchList) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    let startDist = 0;
    let startZoom = 1;
    let focusTime = 0;
    let focusOffset = 0;
    const onStart = (e: TouchEvent) => {
      if (e.touches.length !== 2) return;
      const pps = pxPerSecRef.current;
      if (pps <= 0) return;
      pinchRef.current = true;
      startDist = dist(e.touches);
      startZoom = useEditorStore.getState().zoom;
      const rect = el.getBoundingClientRect();
      focusOffset = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left;
      focusTime = (focusOffset + el.scrollLeft) / pps;
    };
    const onMove = (e: TouchEvent) => {
      if (!pinchRef.current || e.touches.length !== 2 || startDist <= 0) return;
      e.preventDefault(); // own the gesture: no native page zoom / scroll
      pendingFocus.current = { time: focusTime, offset: focusOffset };
      setZoom(clamp((startZoom * dist(e.touches)) / startDist, ZOOM_MIN, ZOOM_MAX));
    };
    const onEnd = (e: TouchEvent) => {
      if (e.touches.length === 0) {
        pinchRef.current = false;
        startDist = 0;
      }
    };
    el.addEventListener('touchstart', onStart, { passive: false });
    el.addEventListener('touchmove', onMove, { passive: false });
    el.addEventListener('touchend', onEnd);
    el.addEventListener('touchcancel', onEnd);
    return () => {
      el.removeEventListener('touchstart', onStart);
      el.removeEventListener('touchmove', onMove);
      el.removeEventListener('touchend', onEnd);
      el.removeEventListener('touchcancel', onEnd);
    };
  }, [setZoom]);

  // Rows render in track order (top to bottom). New elements append to the end,
  // so they appear at the bottom row, and compositing keeps the last track on
  // top, so a freshly added clip is also visible over the others.
  const rowsTopOrder = tracks;

  const timeFromClientX = (clientX: number) => {
    const el = contentRef.current;
    if (!el || pxPerSec <= 0) return 0;
    return clamp((clientX - el.getBoundingClientRect().left) / pxPerSec, 0, displayDuration);
  };
  const trackFromClientY = (clientY: number): string | undefined => {
    const el = rowsRef.current;
    if (!el) return undefined;
    const idx = Math.floor((clientY - el.getBoundingClientRect().top) / ROW_H);
    return rowsTopOrder[clamp(idx, 0, rowsTopOrder.length - 1)]?.id;
  };

  // Capture the pointer on the element the gesture started on, then drive the
  // drag from window-level move/up/cancel. Capturing is what stops a touch drag
  // from being stolen by the scrollable timeline container (the move/up still
  // bubble to window). The returned listeners are torn down on up or cancel.
  const beginDrag = (
    e: ReactPointerEvent,
    move: (ev: PointerEvent) => void,
    up: (ev: PointerEvent) => void,
    capture = true,
  ) => {
    if (capture) {
      try {
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      } catch {
        // setPointerCapture can throw if the pointer is already gone; ignore.
      }
    }
    const onUp = (ev: PointerEvent) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      up(ev);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  };

  // Scroll the timeline view while a drag holds near an edge, so a zoomed-in or
  // tall timeline stays reachable on touch. Vertical scroll is opt-in (pass
  // getClientY) and lets a clip drag reach the "drop to add track" zone at the
  // very bottom regardless of how many tracks there are. Returns a stop function.
  const startEdgeScroll = (getClientX: () => number, onScroll: () => void, getClientY?: () => number) => {
    let raf = 0;
    const tick = () => {
      const sc = scrollRef.current;
      if (sc) {
        const r = sc.getBoundingClientRect();
        const edge = 36;
        let scrolled = false;
        const x = getClientX();
        let dx = 0;
        if (x > r.right - edge) dx = Math.min(24, x - (r.right - edge));
        else if (x < r.left + edge) dx = -Math.min(24, r.left + edge - x);
        if (dx !== 0 && sc.scrollWidth > sc.clientWidth) {
          sc.scrollLeft += dx;
          scrolled = true;
        }
        if (getClientY) {
          const y = getClientY();
          let dy = 0;
          if (y > r.bottom - edge) dy = Math.min(24, y - (r.bottom - edge));
          else if (y < r.top + edge) dy = -Math.min(24, r.top + edge - y);
          if (dy !== 0 && sc.scrollHeight > sc.clientHeight) {
            sc.scrollTop += dy;
            scrolled = true;
          }
        }
        if (scrolled) onScroll();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  };

  // Anywhere that is not a clip (ruler, empty track space, below the tracks):
  // press and drag to scrub the playhead, CapCut-style. A plain tap clears the
  // selection. A horizontal touch drag can't scroll the strip (touch-action is
  // pan-y on the content), so scrubbing past the edge auto-scrolls the view;
  // a vertical drag still scrolls the tracks natively.
  const onAreaPointerDown = (e: ReactPointerEvent) => {
    if (pxPerSec <= 0) return;
    // Ignore the second finger of a pinch so it doesn't start a rival scrub.
    if (!e.isPrimary) return;
    const el = e.currentTarget as HTMLElement;
    const pid = e.pointerId;
    const startX = e.clientX;
    let clientX = e.clientX;
    let moved = false;
    let pinched = false;
    setPlaying(false);
    // Don't seek on press: a two-finger pinch lands one finger first, and seeking
    // here would jump the playhead before the pinch is recognised. Seek on the
    // first real drag move, or on a plain tap (in up), instead.
    const stopEdge = startEdgeScroll(
      () => clientX,
      () => {
        if (!pinchRef.current && moved) setCurrentTime(timeFromClientX(clientX));
      },
    );
    const move = (ev: PointerEvent) => {
      // A pinch took over (a second finger landed): never scrub, just let it zoom.
      if (pinchRef.current) {
        pinched = true;
        return;
      }
      clientX = ev.clientX;
      if (!moved && Math.abs(ev.clientX - startX) > 3) {
        // Once the drag reads as horizontal, lock it to the scrub so it can't
        // become a scroll; a vertical (track) scroll never reaches here.
        moved = true;
        try {
          el.setPointerCapture(pid);
        } catch {
          // ignore
        }
      }
      if (moved) setCurrentTime(timeFromClientX(ev.clientX));
    };
    // Don't capture: with touch-action pan-y on the content, a vertical drag
    // still scrolls the tracks natively, while a horizontal drag scrubs here.
    beginDrag(
      e,
      move,
      (ev) => {
        stopEdge();
        // A plain tap (no drag, no pinch) seeks there and clears the selection.
        if (!moved && !pinched && !pinchRef.current) {
          setCurrentTime(timeFromClientX(ev.clientX));
          clearSelection();
        }
      },
      false,
    );
  };

  const onClipBodyDown = (e: ReactPointerEvent, clipId: string) => {
    e.stopPropagation();
    // Modifier-click toggles a clip in/out of the selection (no drag/seek).
    if (e.metaKey || e.ctrlKey || e.shiftKey) {
      toggleSelect(clipId);
      return;
    }
    const inSelection = selectedIds.includes(clipId);
    // Clicking a clip outside the current selection selects just it.
    if (!inSelection) setActiveClip(clipId);
    const clip = clips.find((c) => c.id === clipId);
    if (!clip) return;

    const group = inSelection && selectedIds.length > 1;
    const startX = e.clientX;
    const startY = e.clientY;
    const dur = clipTimelineDuration(clip);

    // single-drag prep
    const origStart = clip.start;
    const targets = !group && snap ? clipSnapTargets(clips, clipId, currentTime) : [];
    // group-drag prep: capture every selected clip's origin so the translate has no drift
    const groupOrigins = group
      ? selectedIds.map((id) => ({ id, start: clips.find((c) => c.id === id)?.start ?? 0 }))
      : [];
    const minOrigin = group ? Math.min(...groupOrigins.map((o) => o.start)) : 0;

    let moved = false;
    let curStart = origStart;
    let toNewTrack = false;
    let lastX = startX;
    let lastY = startY;
    // Set once a two-finger pinch hijacks this touch: the drag is reverted and
    // the release becomes a no-op so the gesture only zooms.
    let pinchAborted = false;

    // Touch/pen long-press opens the per-clip menu (there's no right-click on
    // touch). It arms on press, cancels on drag or release, and when it fires it
    // flags the gesture so the move/up below neither drag nor seek.
    let longPressed = false;
    let lpTimer: number | undefined;
    const clearLp = () => {
      if (lpTimer !== undefined) {
        clearTimeout(lpTimer);
        lpTimer = undefined;
      }
    };
    if (e.pointerType !== 'mouse') {
      lpTimer = window.setTimeout(() => {
        lpTimer = undefined;
        if (pinchRef.current) return; // a pinch is underway: don't pop the menu
        longPressed = true;
        navigator.vibrate?.(8);
        openClipMenuAt(startX, startY, clipId);
      }, 500);
    }

    // Apply the drag from the latest pointer position. Shared by pointermove and
    // the edge auto-scroll so holding near an edge keeps relocating / dropping.
    const applyDrag = () => {
      if (group) {
        // translate the whole selection, clamped so the earliest clip stays >= 0
        const delta = Math.max((lastX - startX) / pxPerSec, -minOrigin);
        setClipStarts(groupOrigins.map((o) => ({ id: o.id, start: o.start + delta })));
        return;
      }
      let newStart = Math.max(0, origStart + (lastX - startX) / pxPerSec);
      if (snap) newStart = snapStart(newStart, dur, targets, 8 / pxPerSec);
      curStart = newStart;
      // dropping below the last row creates a new track
      const rows = rowsRef.current?.getBoundingClientRect();
      toNewTrack = !!rows && lastY > rows.bottom - 4;
      setOverNewTrack(toNewTrack);
      const dropTarget = trackFromClientY(lastY);
      // Never drop onto a locked track; keep the clip on its own track instead.
      const lockedTarget = dropTarget != null && tracks.find((t) => t.id === dropTarget)?.locked;
      const trackId = toNewTrack
        ? useEditorStore.getState().clips.find((c) => c.id === clipId)?.trackId ?? clip.trackId
        : (lockedTarget ? clip.trackId : dropTarget) ?? clip.trackId;
      // Highlight the target row when relocating onto a different existing track.
      setDropTrackId(!toNewTrack && !lockedTarget && dropTarget && dropTarget !== clip.trackId ? dropTarget : null);
      moveClip(clipId, newStart, trackId);
    };

    // Auto-scroll near the edges so a zoomed/tall timeline stays reachable; the
    // vertical axis (single-clip drags) lets the bottom new-track zone be hit.
    const stopEdge = startEdgeScroll(
      () => lastX,
      () => {
        if (moved && !pinchRef.current) applyDrag();
      },
      group ? undefined : () => lastY,
    );

    const move = (ev: PointerEvent) => {
      if (longPressed) return;
      // A pinch took over: revert any movement and let the gesture only zoom.
      if (pinchRef.current) {
        if (!pinchAborted) {
          pinchAborted = true;
          clearLp();
          if (moved) {
            if (group) setClipStarts(groupOrigins.map((o) => ({ id: o.id, start: o.start })));
            else moveClip(clipId, origStart, clip.trackId);
            setDragClipId(null);
            setOverNewTrack(false);
            setDropTrackId(null);
            moved = false;
          }
        }
        return;
      }
      lastX = ev.clientX;
      lastY = ev.clientY;
      if (!moved && (Math.abs(ev.clientX - startX) > 4 || Math.abs(ev.clientY - startY) > 4)) {
        clearLp();
        moved = true;
        if (!group) setDragClipId(clipId);
      }
      if (!moved) return;
      applyDrag();
    };
    const up = (ev: PointerEvent) => {
      clearLp();
      stopEdge();
      // The long-press menu, or a pinch, already owns this touch: swallow the
      // release so it doesn't seek, relocate or collapse the selection.
      if (longPressed || pinchAborted || pinchRef.current) {
        setDragClipId(null);
        setOverNewTrack(false);
        setDropTrackId(null);
        return;
      }
      if (!moved) {
        // a plain click on a clip already in a multi-selection collapses to just it
        if (group) setActiveClip(clipId);
        setPlaying(false);
        setCurrentTime(timeFromClientX(ev.clientX));
      } else if (!group && toNewTrack) {
        moveClipToNewTrack(clipId, curStart, 'below');
      }
      // Collapse any lane this move left empty so they don't pile up.
      if (moved) pruneEmptyTracks();
      setDragClipId(null);
      setOverNewTrack(false);
      setDropTrackId(null);
    };
    beginDrag(e, move, up);
  };

  const onHandleDown = (e: ReactPointerEvent, clipId: string, edge: 'in' | 'out') => {
    e.stopPropagation();
    setActiveClip(clipId);
    const clip = clips.find((c) => c.id === clipId);
    if (!clip) return;
    const m = media.find((x) => x.id === clip.mediaId);
    const maxOut = m && m.kind === 'video' ? m.duration : Number.POSITIVE_INFINITY;
    const startX = e.clientX;
    const o = { start: clip.start, in: clip.in, out: clip.out, speed: clip.speed };
    setPlaying(false);
    const move = (ev: PointerEvent) => {
      const dxSec = ((ev.clientX - startX) / pxPerSec) * o.speed;
      if (edge === 'out') {
        const newOut = clamp(o.out + dxSec, o.in + 0.1, maxOut);
        updateClip(clipId, { out: newOut });
        // seek to the new out frame so the preview shows what is kept
        setCurrentTime(Math.max(o.start, o.start + (newOut - o.in) / o.speed - 0.03));
      } else {
        const newIn = clamp(o.in + dxSec, 0, o.out - 0.1);
        const newStart = Math.max(0, o.start + (newIn - o.in) / o.speed);
        updateClip(clipId, { in: newIn, start: newStart });
        setCurrentTime(newStart);
      }
    };
    beginDrag(e, move, () => undefined);
  };

  const grabPlayhead = (e: ReactPointerEvent) => {
    e.stopPropagation();
    if (pxPerSec <= 0) return;
    let clientX = e.clientX;
    setPlaying(false);
    setCurrentTime(timeFromClientX(e.clientX));
    const stopEdge = startEdgeScroll(
      () => clientX,
      () => setCurrentTime(timeFromClientX(clientX)),
    );
    const move = (ev: PointerEvent) => {
      clientX = ev.clientX;
      setCurrentTime(timeFromClientX(ev.clientX));
    };
    beginDrag(e, move, () => stopEdge());
  };

  const openClipMenuAt = (clientX: number, clientY: number, id: string) => {
    // Right-click or long-press a clip outside the selection selects just it; otherwise act on the whole selection.
    const already = selectedIds.includes(id);
    if (!already) setActiveClip(id);
    const ids = already ? selectedIds : [id];
    const n = ids.length;
    const suffix = n > 1 ? ` ${n} clips` : '';
    const idSet = new Set(ids);
    const sel = clips.filter((c) => idSet.has(c.id));
    // Clips that carry sound (a video with audio, or standalone/detached audio) can be muted.
    const audioIds = sel
      .filter((c) => {
        const m = media.find((x) => x.id === c.mediaId);
        return m?.kind === 'audio' || (m?.kind === 'video' && m.hasAudio);
      })
      .map((c) => c.id);
    const allMuted = audioIds.length > 0 && audioIds.every((id) => sel.find((c) => c.id === id)!.muted);
    const allHidden = sel.length > 0 && sel.every((c) => c.hidden);
    const single = sel.length === 1 ? sel[0] : undefined;
    const singleMedia = single ? media.find((x) => x.id === single.mediaId) : undefined;
    const singleIsVideo = singleMedia?.kind === 'video';
    const canFreeze =
      !!single &&
      singleIsVideo &&
      !single.audioOnly &&
      single.freeze == null &&
      !single.speedCurve &&
      currentTime > single.start + MIN_CLIP &&
      currentTime < single.start + clipTimelineDuration(single) - MIN_CLIP;
    // Detach a video clip's audio onto its own track (the source clip is muted).
    const canExtract =
      !!single && singleIsVideo && !single.audioOnly && single.freeze == null && !!singleMedia?.hasAudio;
    const items: MenuItem[] = [
      { id: 'split', label: 'Split at playhead', icon: <Scissors size={14} />, shortcut: 'S', onClick: () => splitAt(currentTime) },
      ...((canMergeClips(sel)
        ? [{ id: 'merge', label: 'Merge clips', icon: <Merge size={14} />, shortcut: 'J', onClick: () => mergeClips(ids) }]
        : []) as MenuItem[]),
      ...((canFreeze
        ? [{ id: 'freeze', label: 'Freeze frame', icon: <Snowflake size={14} />, shortcut: 'F', onClick: () => freezeFrame() }]
        : []) as MenuItem[]),
      { id: 'dup', label: `Duplicate${suffix}`, icon: <CopyPlus size={14} />, shortcut: '⌘D', onClick: () => duplicateClips(ids) },
      { id: 'copy', label: `Copy${suffix}`, icon: <Copy size={14} />, shortcut: '⌘C', onClick: () => copyClips(ids) },
      { id: 'paste', label: 'Paste', icon: <Clipboard size={14} />, shortcut: '⌘V', disabled: clipboard.length === 0, onClick: () => pasteClips(currentTime) },
      ...((canExtract
        ? [
            {
              id: 'extract',
              label: 'Extract audio',
              icon: <AudioLines size={14} />,
              separatorBefore: true,
              onClick: () => extractAudio(single!.id),
            },
          ]
        : []) as MenuItem[]),
      ...((audioIds.length > 0
        ? [
            {
              id: 'mute',
              label: allMuted ? 'Unmute' : 'Mute',
              icon: allMuted ? <Volume2 size={14} /> : <VolumeX size={14} />,
              separatorBefore: !canExtract,
              onClick: () => updateClips(audioIds, { muted: !allMuted }),
            },
          ]
        : []) as MenuItem[]),
      { id: 'hide', label: allHidden ? `Show${suffix}` : `Hide${suffix}`, icon: allHidden ? <Eye size={14} /> : <EyeOff size={14} />, separatorBefore: audioIds.length === 0 && !canExtract, onClick: () => updateClips(ids, { hidden: !allHidden }) },
      { id: 'ripple', label: `Ripple delete${suffix}`, icon: <ChevronsLeft size={14} />, shortcut: '⇧Del', separatorBefore: true, onClick: () => rippleDeleteClips(ids) },
      { id: 'del', label: `Delete${suffix}`, icon: <Trash2 size={14} />, shortcut: 'Del', danger: true, onClick: () => deleteClips(ids) },
    ];
    setMenu({ x: clientX, y: clientY, items });
  };

  const openClipMenu = (e: ReactMouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    openClipMenuAt(e.clientX, e.clientY, id);
  };

  const openTrackMenu = (e: ReactMouseEvent, trackId: string) => {
    e.preventDefault();
    const track = tracks.find((t) => t.id === trackId);
    if (!track) return;
    const at = timeFromClientX(e.clientX);
    const trackClips = clips.filter((c) => c.trackId === trackId);
    const trackClipIds = trackClips.map((c) => c.id);
    const trackHasAudio = trackClips.some((c) => {
      const m = media.find((x) => x.id === c.mediaId);
      return m?.kind === 'audio' || (m?.kind === 'video' && m.hasAudio);
    });
    const idx = tracks.findIndex((t) => t.id === trackId);
    const items: MenuItem[] = [
      { id: 'paste', label: 'Paste here', icon: <Clipboard size={14} />, shortcut: '⌘V', disabled: clipboard.length === 0 || track.locked, onClick: () => pasteClips(at) },
      { id: 'select', label: 'Select clips', icon: <MousePointerClick size={14} />, disabled: trackClipIds.length === 0 || track.locked, onClick: () => selectClips(trackClipIds) },
      { id: 'rename', label: 'Rename track', icon: <Pencil size={14} />, separatorBefore: true, onClick: () => setRenamingTrackId(trackId) },
      { id: 'tup', label: 'Move up', icon: <ArrowUpToLine size={14} />, disabled: idx <= 0, onClick: () => moveTrack(trackId, 'up') },
      { id: 'tdown', label: 'Move down', icon: <ArrowDownToLine size={14} />, disabled: idx < 0 || idx >= tracks.length - 1, onClick: () => moveTrack(trackId, 'down') },
      { id: 'tlock', label: track.locked ? 'Unlock track' : 'Lock track', icon: track.locked ? <LockOpen size={14} /> : <Lock size={14} />, onClick: () => setTrackLocked(trackId, !track.locked) },
      ...((trackHasAudio
        ? [
            {
              id: 'tmute',
              label: track.muted ? 'Unmute track' : 'Mute track',
              icon: track.muted ? <Volume2 size={14} /> : <VolumeX size={14} />,
              separatorBefore: true,
              onClick: () => setTrackMuted(trackId, !track.muted),
            },
          ]
        : []) as MenuItem[]),
      { id: 'thide', label: track.hidden ? 'Show track' : 'Hide track', icon: track.hidden ? <Eye size={14} /> : <EyeOff size={14} />, separatorBefore: !trackHasAudio, onClick: () => setTrackHidden(trackId, !track.hidden) },
      { id: 'tdel', label: 'Delete track', icon: <Trash2 size={14} />, danger: true, separatorBefore: true, onClick: () => removeTrack(trackId) },
    ];
    setMenu({ x: e.clientX, y: e.clientY, items });
  };

  const tickStep = niceStep(pxPerSec);

  return (
    <div className="flex h-full flex-col border-t border-line bg-surface/40">
      <div className="flex min-h-12 flex-wrap items-center gap-1.5 border-b border-line/60 px-2 py-1.5 lg:h-12 lg:flex-nowrap lg:gap-2 lg:px-3 lg:py-0">
        <div className="flex items-center gap-1">
          <button
            onClick={() => activeId && addKeyframeAtPlayhead(activeId)}
            disabled={!canKeyframe}
            title={kfAtPlayhead ? 'Update keyframe at playhead' : 'Add keyframe at playhead'}
            aria-label="Add keyframe at playhead"
            className={cn(
              'grid h-8 w-8 place-items-center rounded-lg transition-colors hover:bg-surface-2 disabled:pointer-events-none disabled:opacity-40',
              kfAtPlayhead ? 'text-accent' : 'text-ink-muted hover:text-ink',
            )}
          >
            <Diamond size={16} fill={kfAtPlayhead ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={() => splitAt(currentTime)}
            title="Split at playhead (S)"
            aria-label="Split at playhead"
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink"
          >
            <Scissors size={16} />
          </button>
          <button
            onClick={() => hasSelection && updateClips(selectedIds, { hidden: !allHidden })}
            disabled={!hasSelection}
            title={allHidden ? 'Show selection' : 'Hide selection'}
            aria-label={allHidden ? 'Show selection' : 'Hide selection'}
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink disabled:pointer-events-none disabled:opacity-40"
          >
            {allHidden ? <Eye size={16} /> : <EyeOff size={16} />}
          </button>
          <button
            onClick={() => mutableClips.length > 0 && updateClips(mutableClips.map((c) => c.id), { muted: !allMuted })}
            disabled={mutableClips.length === 0}
            title={allMuted ? 'Unmute selection' : 'Mute selection'}
            aria-label={allMuted ? 'Unmute selection' : 'Mute selection'}
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink disabled:pointer-events-none disabled:opacity-40"
          >
            {allMuted ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
          <button
            onClick={() => hasSelection && deleteClips(selectedIds)}
            disabled={!hasSelection}
            title="Delete selection (Del)"
            aria-label="Delete selection"
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink disabled:pointer-events-none disabled:opacity-40"
          >
            <Trash2 size={16} />
          </button>
          {selectedIds.length > 1 && (
            <span className="ml-1 rounded-md bg-brand/15 px-2 py-0.5 text-xs font-medium text-brand-bright">
              {selectedIds.length} selected
            </span>
          )}
          <div className="mx-0.5 h-5 w-px bg-line/70" />
          <button
            onClick={() => addTrack()}
            title="Add track"
            aria-label="Add track"
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink"
          >
            <Plus size={16} />
          </button>
        </div>

        <div className="order-last flex w-full justify-center lg:order-none lg:mx-auto lg:w-auto">
          <PlaybackControls />
        </div>

        <div className="ml-auto flex items-center gap-1 lg:ml-0">
          <button
            onClick={() => !snapping && snapshot()}
            disabled={snapping || clips.length === 0}
            title="Save a PNG of the current frame"
            aria-label="Snapshot current frame"
            className="grid h-8 w-8 place-items-center rounded-lg text-ink-muted transition-colors hover:bg-surface-2 hover:text-ink disabled:pointer-events-none disabled:opacity-40"
          >
            {snapping ? <Loader2 size={16} className="animate-spin" /> : <Camera size={16} />}
          </button>
          <button
            onClick={toggleSnap}
            title={snap ? 'Snapping on' : 'Snapping off'}
            aria-label="Toggle snapping"
            className={cn(
              'grid h-8 w-8 place-items-center rounded-lg transition-colors',
              snap ? 'bg-surface-3 text-brand-bright' : 'text-ink-muted hover:bg-surface-2 hover:text-ink',
            )}
          >
            <Magnet size={16} />
          </button>
          <ZoomControls />
        </div>
      </div>

      <div ref={scrollRef} className="relative flex-1 overflow-auto overscroll-x-contain">
        <div
          ref={contentRef}
          className="relative touch-pan-y select-none"
          style={{ width: trackW || '100%', minHeight: '100%' }}
          onPointerDown={onAreaPointerDown}
        >
          <div className="sticky top-0 z-20 h-6 border-b border-line/40 bg-surface/80 text-[10px] text-ink-faint backdrop-blur">
            {tickStep > 0 &&
              Array.from({ length: Math.floor(displayDuration / tickStep) + 1 }).map((_, i) => {
                const t = i * tickStep;
                return (
                  <div key={i} className="absolute top-0 h-full" style={{ left: t * pxPerSec }}>
                    <div className="h-1.5 w-px bg-line" />
                    <span className="absolute left-1 top-1.5 whitespace-nowrap">{formatClock(t)}</span>
                  </div>
                );
              })}
          </div>

          <div ref={rowsRef}>
            {rowsTopOrder.length === 0 && (
              <div className="grid h-[120px] place-items-center text-sm text-ink-faint">
                Add media to create a track.
              </div>
            )}
            {rowsTopOrder.map((track) => {
              // Whether the track carries sound, so we only offer a mute toggle then.
              const trackHasAudio = clips.some((c) => {
                if (c.trackId !== track.id) return false;
                const m = media.find((x) => x.id === c.mediaId);
                return m?.kind === 'audio' || (m?.kind === 'video' && m.hasAudio);
              });
              return (
              <div
                key={track.id}
                className={cn(
                  'relative border-b border-line/40',
                  track.locked && 'bg-surface-2/30',
                  dropTrackId === track.id && 'bg-brand/10 ring-2 ring-inset ring-brand/60',
                )}
                style={{ height: ROW_H }}
                onContextMenu={(e) => openTrackMenu(e, track.id)}
              >
                <div className="absolute left-1.5 top-1.5 z-10 flex items-center gap-1">
                  {renamingTrackId === track.id ? (
                    <input
                      autoFocus
                      defaultValue={track.name}
                      onPointerDown={(e) => e.stopPropagation()}
                      onBlur={(e) => {
                        if (renameCancel.current) renameCancel.current = false;
                        else renameTrack(track.id, e.target.value.trim() || track.name);
                        setRenamingTrackId(null);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') e.currentTarget.blur();
                        else if (e.key === 'Escape') {
                          renameCancel.current = true;
                          e.currentTarget.blur();
                        }
                      }}
                      className="h-5 w-28 rounded bg-surface px-1 text-[10px] text-ink outline-none ring-1 ring-brand"
                    />
                  ) : (
                    <button
                      onPointerDown={(e) => e.stopPropagation()}
                      onDoubleClick={() => setRenamingTrackId(track.id)}
                      title="Double-click to rename"
                      className="max-w-[8rem] truncate rounded bg-black/50 px-1.5 py-0.5 text-[10px] font-medium text-ink-muted hover:text-ink"
                    >
                      {track.name}
                    </button>
                  )}
                  {track.locked && (
                    <span className="grid h-5 w-5 place-items-center rounded bg-black/50 text-ink-muted">
                      <Lock size={12} />
                    </span>
                  )}
                  {/* Quick hide/mute toggles: the track context menu isn't reachable on touch. */}
                  <button
                    onPointerDown={(e) => e.stopPropagation()}
                    onClick={() => setTrackHidden(track.id, !track.hidden)}
                    title={track.hidden ? 'Show track' : 'Hide track'}
                    aria-label={track.hidden ? 'Show track' : 'Hide track'}
                    className={cn(
                      'grid h-5 w-5 place-items-center rounded bg-black/50 transition-colors',
                      track.hidden ? 'text-ink-muted' : 'text-ink-faint hover:text-ink',
                    )}
                  >
                    {track.hidden ? <EyeOff size={12} /> : <Eye size={12} />}
                  </button>
                  {trackHasAudio && (
                    <button
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={() => setTrackMuted(track.id, !track.muted)}
                      title={track.muted ? 'Unmute track' : 'Mute track'}
                      aria-label={track.muted ? 'Unmute track' : 'Mute track'}
                      className={cn(
                        'grid h-5 w-5 place-items-center rounded bg-black/50 transition-colors',
                        track.muted ? 'text-danger' : 'text-ink-faint hover:text-ink',
                      )}
                    >
                      {track.muted ? <VolumeX size={12} /> : <Volume2 size={12} />}
                    </button>
                  )}
                </div>
                {clips
                  .filter((c) => c.trackId === track.id)
                  .map((clip) => {
                    const node = (
                      <TimelineClip
                        key={clip.id}
                        clip={clip}
                        media={media.find((m) => m.id === clip.mediaId)}
                        pxPerSec={pxPerSec}
                        currentTime={currentTime}
                        active={clip.id === activeId}
                        selected={selectedIds.includes(clip.id)}
                        onBodyDown={(e) => onClipBodyDown(e, clip.id)}
                        onHandleDown={(e, edge) => onHandleDown(e, clip.id, edge)}
                        onContext={(e) => openClipMenu(e, clip.id)}
                        onKeyframeClick={(at) => {
                          setActiveClip(clip.id);
                          setPlaying(false);
                          setCurrentTime(clip.start + at);
                        }}
                      />
                    );
                    // A locked track's clips can't be grabbed, trimmed or selected.
                    return track.locked ? (
                      <div key={clip.id} className="pointer-events-none opacity-60">
                        {node}
                      </div>
                    ) : (
                      node
                    );
                  })}
              </div>
              );
            })}
          </div>

          {dragClipId && (
            <div
              className={cn(
                'relative mx-1 mb-1 rounded-xl border-2 border-dashed transition-colors',
                overNewTrack ? 'border-brand bg-brand/10' : 'border-line/60 bg-surface-2/20',
              )}
              style={{ height: ROW_H - 10 }}
            >
              {(() => {
                const dc = overNewTrack ? clips.find((c) => c.id === dragClipId) : undefined;
                return dc ? (
                  <div
                    className="pointer-events-none absolute inset-y-1 rounded-lg bg-brand/30 ring-1 ring-brand"
                    style={{
                      left: dc.start * pxPerSec,
                      width: Math.max(10, clipTimelineDuration(dc) * pxPerSec),
                    }}
                  />
                ) : (
                  <span className="pointer-events-none absolute inset-0 grid place-items-center text-xs font-medium text-ink-faint">
                    Drop here to add a track
                  </span>
                );
              })()}
            </div>
          )}

          <Playhead left={currentTime * pxPerSec} onGrab={grabPlayhead} />
        </div>
      </div>

      <ContextMenu menu={menu} onClose={() => setMenu(null)} />
    </div>
  );
}
