export type AspectRatioId = 'original' | '16:9' | '9:16' | '1:1' | '4:5' | '4:3' | '21:9';

export interface AspectRatioOption {
  id: AspectRatioId;
  label: string;
  hint: string;
  ratio: number;
}

/** A placement rectangle on the output canvas, as fractions (0..1). */
export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export const FULL_RECT: Rect = { x: 0, y: 0, w: 1, h: 1 };

/** True when a rect covers the whole frame (no crop / full placement). */
export function isFullRect(r?: Rect | null): boolean {
  return !r || (r.x <= 1e-4 && r.y <= 1e-4 && r.w >= 1 - 1e-4 && r.h >= 1 - 1e-4);
}

/**
 * A transform keyframe: the clip's placement `rect` at a moment `at` (timeline
 * seconds from the clip's start). A clip's keyframes are interpolated
 * piecewise-linearly to animate position + scale (Ken Burns, moving PiP). The
 * box keeps its aspect across keyframes, so the animation is a uniform
 * scale + translate, which keeps the preview and export exactly in sync.
 */
export interface Keyframe {
  at: number;
  rect: Rect;
  /** Animated opacity (0..1) at this keyframe; absent = the clip's static opacity. */
  opacity?: number;
}

export type MediaKind = 'video' | 'image' | 'audio';

export interface MediaItem {
  id: string;
  kind: MediaKind;
  fileName: string;
  mimeType: string;
  size: number;
  /** seconds (0 for images). */
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  /** object URL (runtime only, not persisted). */
  url: string;
  /** source bytes (runtime only, persisted separately in IndexedDB). */
  blob: Blob;
}

export type MediaMeta = Omit<MediaItem, 'url' | 'blob'>;

export interface Track {
  id: string;
  name: string;
  hidden: boolean;
  muted: boolean;
  /** When locked, the track's clips can't be selected, moved, trimmed or edited. */
  locked?: boolean;
}

export type TextAlign = 'left' | 'center' | 'right';

/** Styling for a text overlay. `fontSize` is a fraction of the canvas height so it scales with resolution. */
export interface TextStyle {
  content: string;
  /** CSS font-family string, also valid for the canvas `font` shorthand. */
  fontFamily: string;
  /** fraction of canvas height (e.g. 0.1 = 10% of height). */
  fontSize: number;
  fontWeight: number;
  italic: boolean;
  color: string;
  align: TextAlign;
  /** line spacing multiplier. */
  lineHeight: number;
  /** background box color, or null for none. */
  background: string | null;
  backgroundOpacity: number;
  shadow: boolean;
  /** outline color drawn around the glyphs (paired with `strokeWidth`). */
  strokeColor?: string;
  /** outline thickness as a fraction of the font size; 0 / undefined = no outline. */
  strokeWidth?: number;
  /**
   * Karaoke word-highlight color. When set on a caption clip (which carries
   * per-word timings), spoken-so-far words are painted in this color, live in the
   * preview and burned per-word on export. Absent = no highlight.
   */
  highlightColor?: string;
}

/**
 * A clip placed on a track. `start` is its timeline position (seconds); `in`/`out`
 * are the trimmed source range. Timeline length is (out-in)/speed. `rect` places
 * it on the output canvas (fractions); `opacity` 0..1. A clip with `text` is a
 * text overlay (it has no media and `mediaId` is empty).
 */
export interface Clip {
  id: string;
  mediaId: string;
  trackId: string;
  start: number;
  in: number;
  out: number;
  speed: number;
  rect: Rect;
  opacity: number;
  muted: boolean;
  hidden: boolean;
  /** mirror horizontally */
  flipH: boolean;
  /** flip vertically */
  flipV: boolean;
  /** clockwise rotation in degrees (0, 90, 180, 270) */
  rotation: number;
  /** play the clip backwards (video `reverse` + audio `areverse` on export). */
  reversed?: boolean;
  /** linear audio gain (1 = original level). */
  volume: number;
  /** audio fade-in length, in timeline seconds. */
  fadeIn: number;
  /** audio fade-out length, in timeline seconds. */
  fadeOut: number;
  /**
   * When true the clip contributes only audio (no video overlay). Set by
   * "extract audio" on a video clip; audio-kind media is inherently audio-only.
   */
  audioOnly?: boolean;
  text?: TextStyle;
  /** Enter/exit animation for a text overlay (burned into the export). */
  textAnim?: TextAnim;
  /** Vector shape/sticker overlay (no media); mutually exclusive with `text`/media. */
  shape?: ShapeStyle;
  /**
   * Source-time (seconds) held as a still. When set, the clip shows that single
   * frame for its whole timeline length; `in`/`out` act as the hold window and
   * `speed` is 1. Created by the freeze-frame action.
   */
  freeze?: number;
  /** Variable-speed profile across the clip; overrides the constant `speed`. */
  speedCurve?: SpeedCurve;
  /** Color / filter adjustment (brightness, contrast, saturation, hue). */
  color?: ColorAdjust;
  /** Chroma key (green-screen removal); when set the key color becomes transparent. */
  chromaKey?: ChromaKey;
  /** Static video effects (blur, pixelate, RGB-split, grain); absent = none. */
  effects?: VideoEffects;
  /** Shape mask cutting the clip to a linear / circle / rectangle; absent = none. */
  mask?: ClipMask;
  /** Source crop: the sub-rectangle of the media (fractions 0..1) kept before the cover scale; absent = full frame. */
  crop?: Rect;
  /** Blend mode against the layers below this overlay clip (absent = normal). */
  blendMode?: BlendMode;
  /**
   * A transition INTO this clip from the previous clip on the same track. The
   * clip overlaps its predecessor by `duration` seconds; that overlap is where
   * the cross-dissolve / fade happens.
   */
  transition?: Transition;
  /**
   * Transform animation: position + scale keyframes over the clip's timeline.
   * When 2+ are present the clip's `rect` is interpolated between them instead
   * of held static; fewer than 2 leaves `rect` static (no change).
   */
  keyframes?: Keyframe[];
  /**
   * Marks the clip as an auto-caption line (a text clip created by the captions
   * tool) and carries optional per-word timings, used by the caption manager
   * and a future word-by-word highlight. Presence is the marker; `words` is
   * relative to the clip's start in timeline seconds.
   */
  caption?: CaptionMeta;
}

/** A single transcribed word with timing relative to its caption clip's start (seconds). */
export interface CaptionWord {
  text: string;
  start: number;
  end: number;
}

/** Metadata attached to an auto-caption text clip. */
export interface CaptionMeta {
  words?: CaptionWord[];
}

export function isTextClip(clip: Clip): clip is Clip & { text: TextStyle } {
  return clip.text != null;
}

/** A caption clip is a text clip created by the auto-captions tool. */
export function isCaptionClip(clip: Clip): clip is Clip & { text: TextStyle; caption: CaptionMeta } {
  return clip.caption != null && clip.text != null;
}

/** Text overlay enter/exit animation kinds (`fade` only changes opacity). */
export type TextAnimId = 'fade' | 'slideUp' | 'slideDown' | 'slideLeft' | 'slideRight';

export interface TextAnim {
  /** entrance animation, or null for none. */
  in: TextAnimId | null;
  /** exit animation, or null for none. */
  out: TextAnimId | null;
  /** length of each of the in/out ramps, in timeline seconds. */
  duration: number;
}

export interface TextAnimOption {
  id: TextAnimId;
  label: string;
}

export const TEXT_ANIMS: TextAnimOption[] = [
  { id: 'fade', label: 'Fade' },
  { id: 'slideUp', label: 'Slide up' },
  { id: 'slideDown', label: 'Slide down' },
  { id: 'slideLeft', label: 'Slide left' },
  { id: 'slideRight', label: 'Slide right' },
];

export const DEFAULT_TEXT_ANIM: TextAnim = { in: 'fade', out: 'fade', duration: 0.4 };

/** How far (fraction of the text box) a slide animation travels. */
export const TEXT_ANIM_OFFSET = 0.6;

/**
 * Enter-direction offset unit for a slide animation: the box starts shifted by
 * this (× {@link TEXT_ANIM_OFFSET} of its size) and eases to centre, then exits
 * the opposite way. `fade` and a missing id contribute no movement.
 */
export function textAnimUnit(id: TextAnimId | null | undefined): { ux: number; uy: number } {
  switch (id) {
    case 'slideUp':
      return { ux: 0, uy: 1 };
    case 'slideDown':
      return { ux: 0, uy: -1 };
    case 'slideLeft':
      return { ux: 1, uy: 0 };
    case 'slideRight':
      return { ux: -1, uy: 0 };
    default:
      return { ux: 0, uy: 0 };
  }
}

/** Built-in vector shapes/stickers, drawn by a shared canvas renderer. */
export type ShapeKind = 'rectangle' | 'ellipse' | 'triangle' | 'diamond' | 'star' | 'arrow';

export interface ShapeStyle {
  kind: ShapeKind;
  /** fill color (#rrggbb) or 'none'. */
  fill: string;
  /** outline color (#rrggbb). */
  stroke: string;
  /** outline width as a fraction of the box's short side (0 = no outline). */
  strokeWidth: number;
  /** corner radius for the rectangle, fraction of the short side (0..0.5). */
  radius: number;
}

export interface ShapeOption {
  kind: ShapeKind;
  label: string;
}

export const SHAPES: ShapeOption[] = [
  { kind: 'rectangle', label: 'Rectangle' },
  { kind: 'ellipse', label: 'Ellipse' },
  { kind: 'triangle', label: 'Triangle' },
  { kind: 'diamond', label: 'Diamond' },
  { kind: 'star', label: 'Star' },
  { kind: 'arrow', label: 'Arrow' },
];

export const DEFAULT_SHAPE_STYLE: Omit<ShapeStyle, 'kind'> = {
  fill: '#8b5cf6',
  stroke: '#ffffff',
  strokeWidth: 0,
  radius: 0.12,
};

/** Default placement for a new shape (a roughly square centered box). */
export const DEFAULT_SHAPE_RECT: Rect = { x: 0.36, y: 0.3, w: 0.28, h: 0.4 };

export function isShapeClip(clip: Clip): clip is Clip & { shape: ShapeStyle } {
  return clip.shape != null;
}

export type SpeedCurveId = 'rampUp' | 'rampDown' | 'bulletTime';

/** A control point on a speed curve: `at` is source progress 0..1, `speed` in ×. */
export interface SpeedPoint {
  at: number;
  speed: number;
}

/** A variable-speed profile, given as piecewise-linear control points (absolute ×). */
export interface SpeedCurve {
  preset: SpeedCurveId;
  points: SpeedPoint[];
}

export interface SpeedCurveOption {
  id: SpeedCurveId;
  label: string;
  hint: string;
  points: SpeedPoint[];
}

/**
 * Built-in speed curves. Points are absolute speeds (×) over the clip's source
 * progress; the first/last `at` are 0 and 1. Realised as constant-speed slices
 * for preview and export, so what you see matches the render.
 */
export const SPEED_CURVES: SpeedCurveOption[] = [
  {
    id: 'rampUp',
    label: 'Ramp up',
    hint: 'Slow → fast',
    points: [
      { at: 0, speed: 0.4 },
      { at: 1, speed: 2 },
    ],
  },
  {
    id: 'rampDown',
    label: 'Ramp down',
    hint: 'Fast → slow',
    points: [
      { at: 0, speed: 2 },
      { at: 1, speed: 0.4 },
    ],
  },
  {
    id: 'bulletTime',
    label: 'Bullet time',
    hint: 'Slow-mo middle',
    points: [
      { at: 0, speed: 2 },
      { at: 0.5, speed: 0.4 },
      { at: 1, speed: 2 },
    ],
  },
];

export function speedCurveById(id: SpeedCurveId): SpeedCurveOption {
  return SPEED_CURVES.find((c) => c.id === id) ?? SPEED_CURVES[0];
}

/** Build a stored SpeedCurve from a preset id. */
export function makeSpeedCurve(id: SpeedCurveId): SpeedCurve {
  const opt = speedCurveById(id);
  return { preset: id, points: opt.points.map((p) => ({ ...p })) };
}

/**
 * Per-clip color grade. The four legacy knobs (brightness, contrast, saturation
 * = 1 unchanged; hue = degrees) map to CSS `filter` + ffmpeg `eq`/`hue`. The
 * deeper, optional fields are a CapCut-style Adjust panel; each is 0 = neutral
 * (sharpen/vignette: 0 = off) and is rendered by a shared WebGL shader in
 * preview and a matching ffmpeg chain on export, so what you see is what burns.
 */
export interface ColorAdjust {
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
  /** White balance, -100 (cool/blue) .. 100 (warm/amber). */
  temperature?: number;
  /** Green ↔ magenta balance, -100 (green) .. 100 (magenta). */
  tint?: number;
  /** Multiplicative exposure, -100 .. 100 (±~1.5 stops at the extremes). */
  exposure?: number;
  /** Bright-tone lift/recover, -100 .. 100. */
  highlights?: number;
  /** Dark-tone lift/crush, -100 .. 100. */
  shadows?: number;
  /** Unsharp-mask amount, 0 (off) .. 100. */
  sharpen?: number;
  /** Edge darkening, 0 (off) .. 100. */
  vignette?: number;
  /** Strength of the whole grade, 0 (original) .. 1 (full); absent = full. */
  intensity?: number;
  /** Bundled or imported 3D LUT look id applied after the knobs (absent = none). */
  lut?: string;
}

export const NEUTRAL_COLOR: ColorAdjust = { brightness: 1, contrast: 1, saturation: 1, hue: 0 };

/**
 * Static video effects layered on top of the color grade. Each is 0 = off ..
 * 100, sized relative to the clip's frame so the look is resolution-independent.
 * `blur` previews as CSS `blur()`; the other three preview through the WebGL
 * clip shader. All four map to a matched ffmpeg node on export (`gblur`,
 * `pixelize`, `rgbashift`, `noise`), applied after the grade and chroma key.
 */
export interface VideoEffects {
  /** Gaussian blur, 0 (off) .. 100. */
  blur?: number;
  /** Pixelate / mosaic block size, 0 (off) .. 100. */
  pixelate?: number;
  /** RGB split / chromatic aberration, 0 (off) .. 100. */
  rgbSplit?: number;
  /** Film grain, 0 (off) .. 100. */
  grain?: number;
}

/** Mask shapes a clip can be cut to (linear edge, ellipse, rectangle). */
export type MaskShape = 'linear' | 'circle' | 'rectangle';

export interface MaskShapeOption {
  id: MaskShape;
  label: string;
}

export const MASK_SHAPES: MaskShapeOption[] = [
  { id: 'linear', label: 'Linear' },
  { id: 'circle', label: 'Circle' },
  { id: 'rectangle', label: 'Rectangle' },
];

/**
 * A shape mask cut into a clip: keeps the pixels inside the shape and hides the
 * rest (or the reverse, when `invert`). `x`/`y` are the centre as a fraction of
 * the clip box; `size` is the radius (circle) / half-extent (rectangle) as a
 * fraction of the box; `angle` aims the linear edge (degrees); `feather` softens
 * the edge (0..100). Previews as a CSS mask and exports as a matched `geq` alpha,
 * reusing the alpha-mask engine that powers wipe / iris transitions.
 */
export interface ClipMask {
  shape: MaskShape;
  x: number;
  y: number;
  size: number;
  angle: number;
  feather: number;
  invert: boolean;
}

export const DEFAULT_MASK: ClipMask = {
  shape: 'circle',
  x: 0.5,
  y: 0.5,
  size: 0.4,
  angle: 0,
  feather: 12,
  invert: false,
};

/**
 * Chroma key (green-screen) settings. `color` is the keyed-out color (#rrggbb);
 * `similarity` widens the matched color range; `blend` softens the alpha edge.
 * Maps to ffmpeg `chromakey` on export and a UV-distance shader in the preview.
 */
export interface ChromaKey {
  color: string;
  similarity: number;
  blend: number;
}

export const DEFAULT_CHROMA: ChromaKey = { color: '#00ff00', similarity: 0.3, blend: 0.1 };

/** Common green/blue screen colors offered in the tool. */
export const CHROMA_SWATCHES = ['#00ff00', '#00d426', '#0047ff', '#1f6fff'];

/**
 * Transition between two adjacent clips on a track, applied over the leading
 * overlap. `dissolve` cross-fades; `fadeBlack`/`fadeWhite` dip through a solid
 * color; `slide*` slides the incoming clip in from an edge; `wipe*` reveals it
 * behind a moving edge; `circleOpen` reveals it in a growing circle (iris).
 * `duration` is the overlap length in timeline seconds.
 */
export type TransitionId =
  | 'dissolve'
  | 'fadeBlack'
  | 'fadeWhite'
  | 'slideLeft'
  | 'slideRight'
  | 'slideUp'
  | 'slideDown'
  | 'wipeLeft'
  | 'wipeRight'
  | 'wipeUp'
  | 'wipeDown'
  | 'circleOpen';

export interface Transition {
  type: TransitionId;
  duration: number;
}

export interface TransitionOption {
  id: TransitionId;
  label: string;
}

export const TRANSITIONS: TransitionOption[] = [
  { id: 'dissolve', label: 'Dissolve' },
  { id: 'fadeBlack', label: 'Fade · black' },
  { id: 'fadeWhite', label: 'Fade · white' },
  { id: 'slideRight', label: 'Slide →' },
  { id: 'slideLeft', label: 'Slide ←' },
  { id: 'slideDown', label: 'Slide ↓' },
  { id: 'slideUp', label: 'Slide ↑' },
  { id: 'wipeRight', label: 'Wipe →' },
  { id: 'wipeLeft', label: 'Wipe ←' },
  { id: 'wipeDown', label: 'Wipe ↓' },
  { id: 'wipeUp', label: 'Wipe ↑' },
  { id: 'circleOpen', label: 'Iris' },
];

/**
 * Blend mode for an overlay clip against the layers below it (absent = normal).
 * Every id maps cleanly to both a CSS `mix-blend-mode` (preview) and an ffmpeg
 * `blend=all_mode` (export), so the look matches in both.
 */
export type BlendMode = 'screen' | 'multiply' | 'overlay' | 'softlight' | 'lighten' | 'darken';

export interface BlendModeOption {
  id: BlendMode;
  label: string;
}

export const BLEND_MODES: BlendModeOption[] = [
  { id: 'screen', label: 'Screen' },
  { id: 'multiply', label: 'Multiply' },
  { id: 'overlay', label: 'Overlay' },
  { id: 'softlight', label: 'Soft light' },
  { id: 'lighten', label: 'Lighten' },
  { id: 'darken', label: 'Darken' },
];

export type ExportFormat = 'mp4' | 'webm' | 'gif' | 'mp3' | 'wav' | 'png';
export type ExportQuality = 'high' | 'medium' | 'low';

/** Audio-only output formats (no video track is rendered). */
export function isAudioFormat(format: ExportFormat): boolean {
  return format === 'mp3' || format === 'wav';
}
/** Target short-side resolution in pixels (e.g. 1080 renders 1080p). */
export type ExportResolution = 480 | 720 | 1080 | 1440 | 2160;
export type ExportFps = 24 | 25 | 30 | 50 | 60;

export interface ExportSettings {
  format: ExportFormat;
  quality: ExportQuality;
  resolution: ExportResolution;
  fps: ExportFps;
  /** Include an audio track in the render (always silent for GIF). */
  audio: boolean;
  /** Audio bitrate in kbps (AAC for MP4, Opus for WebM). */
  audioBitrate: number;
  /**
   * Optional target video bitrate in kbps. When set (> 0) the encoder targets
   * that bitrate (predictable file size); when omitted it uses the quality
   * preset's CRF (better quality per byte, but size varies with content).
   */
  videoBitrate?: number;
}

export const DEFAULT_EXPORT_SETTINGS: ExportSettings = {
  format: 'mp4',
  quality: 'high',
  resolution: 1080,
  fps: 30,
  audio: true,
  audioBitrate: 192,
};

/** Audio bitrate choices (kbps) offered in the export dialog. */
export const AUDIO_BITRATES = [128, 192, 256, 320] as const;

/** Sensible default target video bitrate (kbps) per resolution for custom mode. */
export const RECOMMENDED_VIDEO_KBPS: Record<ExportResolution, number> = {
  480: 1500,
  720: 4000,
  1080: 8000,
  1440: 16000,
  2160: 35000,
};

/** A user-imported 3D LUT held in the project. `id` is `custom:<uid>`. */
export interface CustomLut {
  id: string;
  name: string;
  /** raw `.cube` file text. */
  cube: string;
}

/** A user-imported font held in the project. `id` is `font:<uid>`. */
export interface CustomFont {
  id: string;
  /** human-friendly name shown in the picker (derived from the file name). */
  label: string;
  /** CSS font-family stack stored verbatim on a clip's `text.fontFamily`. */
  family: string;
  /** base64 `data:` URL of the font file, used to re-register and persist it. */
  dataUrl: string;
}

export interface ProjectSnapshot {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  media: MediaMeta[];
  tracks: Track[];
  clips: Clip[];
  aspect: AspectRatioId;
  background: string;
  muted: boolean;
  exportSettings: ExportSettings;
  /** user-imported LUT looks referenced by clips' `color.lut`. */
  customLuts?: CustomLut[];
  /** user-imported fonts referenced by text clips' `text.fontFamily`. */
  customFonts?: CustomFont[];
  /** small JPEG data URL poster for the projects list (optional, best-effort). */
  thumbnail?: string;
}

export const ASPECT_RATIOS: AspectRatioOption[] = [
  { id: '16:9', label: '16:9', hint: 'Widescreen', ratio: 16 / 9 },
  { id: '9:16', label: '9:16', hint: 'Reels / TikTok', ratio: 9 / 16 },
  { id: '1:1', label: '1:1', hint: 'Square', ratio: 1 },
  { id: '4:5', label: '4:5', hint: 'Portrait', ratio: 4 / 5 },
  { id: '4:3', label: '4:3', hint: 'Classic', ratio: 4 / 3 },
  { id: '21:9', label: '21:9', hint: 'Cinematic', ratio: 21 / 9 },
];

export const SPEED_PRESETS = [0.25, 0.5, 1, 1.5, 2, 4] as const;

/** Output canvas background, shown behind clips that don't fill the frame. */
export const DEFAULT_BACKGROUND = '#000000';

/** Sentinel `background` value: fill the canvas with a blurred, cover-scaled copy
 *  of the base clip (the popular vertical-reframe look) instead of a solid color. */
export const BACKGROUND_BLUR = 'blur';

/** `background` prefix for an image fill: `image:<mediaId>` of an imported image. */
export const BACKGROUND_IMAGE_PREFIX = 'image:';

/** True when the background is an image fill (`image:<mediaId>`). */
export function isImageBackground(bg: string): boolean {
  return bg.startsWith(BACKGROUND_IMAGE_PREFIX);
}

/** The media id of an image background, or undefined for color / blur. */
export function backgroundImageId(bg: string): string | undefined {
  return bg.startsWith(BACKGROUND_IMAGE_PREFIX) ? bg.slice(BACKGROUND_IMAGE_PREFIX.length) : undefined;
}

export const BACKGROUND_SWATCHES = [
  '#000000',
  '#ffffff',
  '#0a0a11',
  '#8b5cf6',
  '#22d3ee',
  '#f43f5e',
  '#fbbf24',
  '#34d399',
];

export interface FontOption {
  label: string;
  /** CSS font-family stack, used verbatim for both DOM and canvas rendering. */
  family: string;
}

/**
 * Curated, web-safe font stacks. They render the same in the canvas preview and
 * the canvas-rasterized export (same machine), so what you see is what you get,
 * with no network or bundled font files. Add self-hosted families here later.
 */
export const FONT_OPTIONS: FontOption[] = [
  { label: 'Inter', family: "'Inter', system-ui, sans-serif" },
  { label: 'Arial', family: 'Arial, Helvetica, sans-serif' },
  { label: 'Helvetica', family: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
  { label: 'Verdana', family: 'Verdana, Geneva, sans-serif' },
  { label: 'Tahoma', family: 'Tahoma, Geneva, Verdana, sans-serif' },
  { label: 'Trebuchet', family: "'Trebuchet MS', Tahoma, sans-serif" },
  { label: 'Gill Sans', family: "'Gill Sans', 'Gill Sans MT', Calibri, sans-serif" },
  { label: 'Futura', family: "Futura, 'Trebuchet MS', Arial, sans-serif" },
  { label: 'Century Gothic', family: "'Century Gothic', 'Apple Gothic', sans-serif" },
  { label: 'Optima', family: "Optima, Candara, 'Segoe UI', sans-serif" },
  { label: 'Lucida', family: "'Lucida Sans Unicode', 'Lucida Grande', sans-serif" },
  { label: 'Impact', family: 'Impact, Haettenschweiler, sans-serif' },
  { label: 'Georgia', family: 'Georgia, Cambria, serif' },
  { label: 'Times', family: "'Times New Roman', Times, serif" },
  { label: 'Palatino', family: "'Palatino Linotype', 'Book Antiqua', Palatino, serif" },
  { label: 'Garamond', family: "Garamond, 'EB Garamond', 'Times New Roman', serif" },
  { label: 'Baskerville', family: "Baskerville, 'Baskerville Old Face', Georgia, serif" },
  { label: 'Didot', family: "Didot, 'Bodoni MT', 'Times New Roman', serif" },
  { label: 'Rockwell', family: "Rockwell, 'Rockwell Nova', 'Courier Bold', serif" },
  { label: 'Courier', family: "'Courier New', Courier, monospace" },
  { label: 'Consolas', family: "Consolas, 'Andale Mono', Monaco, monospace" },
  { label: 'Comic Sans', family: "'Comic Sans MS', 'Comic Sans', cursive" },
  { label: 'Brush Script', family: "'Brush Script MT', 'Segoe Script', cursive" },
  { label: 'Copperplate', family: "Copperplate, 'Copperplate Gothic Light', fantasy" },
  { label: 'Papyrus', family: "Papyrus, 'Comic Sans MS', fantasy" },
];

export const DEFAULT_TEXT_STYLE: TextStyle = {
  content: 'Your text',
  fontFamily: FONT_OPTIONS[0].family,
  fontSize: 0.1,
  fontWeight: 700,
  italic: false,
  color: '#ffffff',
  align: 'center',
  lineHeight: 1.2,
  background: null,
  backgroundOpacity: 0.5,
  shadow: true,
  strokeColor: '#000000',
  strokeWidth: 0,
};

/** Default text box: a centered lower third (fractions of the canvas). */
export const DEFAULT_TEXT_RECT: Rect = { x: 0.1, y: 0.66, w: 0.8, h: 0.2 };

/** Where a caption line sits on the canvas. */
export type CaptionPosition = 'bottom' | 'center' | 'top';

/** The caption box for a position preset (fractions of the canvas). */
export function captionRect(position: CaptionPosition): Rect {
  const w = 0.84;
  const h = 0.2;
  const x = (1 - w) / 2;
  const y = position === 'top' ? 0.06 : position === 'center' ? (1 - h) / 2 : 0.74;
  return { x, y, w, h };
}

export interface CaptionPreset {
  id: string;
  label: string;
  /** Style overrides applied on top of {@link DEFAULT_TEXT_STYLE} for every caption. */
  style: Partial<TextStyle>;
}

/**
 * Quick caption looks applied to all captions at once. Kept to fields the text
 * renderer already supports (font, weight, color, box, shadow, size) so what
 * you see in the preview is exactly what burns in on export.
 */
export const CAPTION_PRESETS: CaptionPreset[] = [
  {
    id: 'classic',
    label: 'Classic',
    style: { fontWeight: 700, color: '#ffffff', background: null, shadow: true, fontSize: 0.078 },
  },
  {
    id: 'boxed',
    label: 'Boxed',
    style: {
      fontWeight: 700,
      color: '#ffffff',
      background: '#000000',
      backgroundOpacity: 0.62,
      shadow: false,
      fontSize: 0.07,
    },
  },
  {
    id: 'bold',
    label: 'Bold',
    style: {
      fontFamily: 'Impact, Haettenschweiler, sans-serif',
      fontWeight: 800,
      color: '#ffffff',
      background: null,
      shadow: true,
      fontSize: 0.105,
    },
  },
  {
    id: 'pop',
    label: 'Pop',
    style: { fontWeight: 800, color: '#fbbf24', background: null, shadow: true, fontSize: 0.095 },
  },
];

export interface ResolutionOption {
  id: ExportResolution;
  label: string;
  hint: string;
}

export const RESOLUTIONS: ResolutionOption[] = [
  { id: 480, label: '480p', hint: 'SD' },
  { id: 720, label: '720p', hint: 'HD' },
  { id: 1080, label: '1080p', hint: 'Full HD' },
  { id: 1440, label: '1440p', hint: '2K' },
  { id: 2160, label: '2160p', hint: '4K' },
];

export const FPS_PRESETS: ExportFps[] = [24, 25, 30, 50, 60];

export interface ExportPreset {
  id: string;
  label: string;
  hint: string;
  aspect: AspectRatioId;
  resolution: ExportResolution;
  fps: ExportFps;
}

/**
 * One-tap export presets for common destinations. Applying one sets the project
 * aspect ratio together with the export resolution and frame rate, the way
 * CapCut's "platform" presets do.
 */
export const EXPORT_PRESETS: ExportPreset[] = [
  { id: 'tiktok', label: 'TikTok / Reels', hint: '9:16 · 1080p', aspect: '9:16', resolution: 1080, fps: 30 },
  { id: 'shorts', label: 'YT Shorts', hint: '9:16 · 60fps', aspect: '9:16', resolution: 1080, fps: 60 },
  { id: 'youtube', label: 'YouTube', hint: '16:9 · 1080p', aspect: '16:9', resolution: 1080, fps: 30 },
  { id: 'youtube4k', label: 'YouTube 4K', hint: '16:9 · 2160p', aspect: '16:9', resolution: 2160, fps: 30 },
  { id: 'instagram', label: 'Instagram', hint: '1:1 · 1080p', aspect: '1:1', resolution: 1080, fps: 30 },
  { id: 'portrait', label: 'Insta Portrait', hint: '4:5 · 1080p', aspect: '4:5', resolution: 1080, fps: 30 },
];

export function aspectById(id: AspectRatioId): AspectRatioOption {
  return ASPECT_RATIOS.find((a) => a.id === id) ?? ASPECT_RATIOS[0];
}

/**
 * Numeric canvas ratio for an aspect. Fixed aspects use their preset; 'original'
 * matches the first source video (so nothing is cropped), falling back to the
 * first sized media, then 16:9.
 */
export function resolveAspectRatio(
  aspect: AspectRatioId,
  media: Pick<MediaItem, 'kind' | 'width' | 'height'>[],
): number {
  if (aspect !== 'original') return aspectById(aspect).ratio;
  const src =
    media.find((m) => m.kind === 'video' && m.width > 0 && m.height > 0) ??
    media.find((m) => m.width > 0 && m.height > 0);
  return src ? src.width / src.height : 16 / 9;
}

/** Output canvas pixel size for an aspect ratio at a target short-side resolution (even). */
export function canvasSize(ratio: number, shortSide = 1080): { width: number; height: number } {
  let w: number;
  let h: number;
  if (ratio >= 1) {
    h = shortSide;
    w = Math.round(shortSide * ratio);
  } else {
    w = shortSide;
    h = Math.round(shortSide / ratio);
  }
  const even = (n: number) => Math.max(2, Math.round(n / 2) * 2);
  return { width: even(w), height: even(h) };
}
